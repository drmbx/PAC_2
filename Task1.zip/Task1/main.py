import cv2
import torch
from torchvision import models
from torchvision import transforms

avgpool_features = None


def get_features(module, inputs, output):
    global avgpool_features
    avgpool_features = output


model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
model.layer4.register_forward_hook(get_features)
model.eval()

with open("id_to_human.txt") as file:
    label = [line.strip() for line in file.readlines()]

transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

video_path = "video.mp4"
cap = cv2.VideoCapture(video_path)
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imshow('Video', frame)
    frame = transform(frame).unsqueeze(0)
    out = model(frame)
    _, predicted_class = torch.max(out, 1)
    print("Predicted class: ", label[predicted_class.item()])
    if cv2.waitKey(25) & 0xFF == ord('q'):
        break
